package com.jr.poemas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MARomanticos extends AppCompatActivity implements View.OnClickListener {
private Button buttonPR1, buttonPR2, buttonPR3, buttonClose;
private TextView txtPoema;
private ImageView imgPoema;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maromanticos);

    buttonPR1 = findViewById(R.id.btnPoema1);
    buttonPR1.setOnClickListener(this);

    buttonPR2 = findViewById(R.id.btnPoema2);
    buttonPR2.setOnClickListener(this);

    buttonPR3 = findViewById(R.id.btnPoema3);
    buttonPR3.setOnClickListener(this);

    buttonClose = findViewById(R.id.btnCloseR);
    buttonClose.setOnClickListener(this);

    imgPoema = findViewById(R.id.imgRomanticos);
    txtPoema = findViewById(R.id.txtRomanticos);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnPoema1:{
                txtPoema.setText(R.string.R1);
                imgPoema.setImageResource(R.drawable.ic_benedetti);

                // finish();

                break;
            }
            case R.id.btnPoema2:{
                txtPoema.setText(R.string.R2);
                imgPoema.setImageResource(R.drawable.ic_vargas_llosa);

                break;
            }
            case R.id.btnPoema3:{
                txtPoema.setText(R.string.R3);
                imgPoema.setImageResource(R.drawable.ic_neruda);
                break;
            }

            case R.id.btnCloseR: {
                finish();
                break;
            }
            default: break;
        }



    }
}