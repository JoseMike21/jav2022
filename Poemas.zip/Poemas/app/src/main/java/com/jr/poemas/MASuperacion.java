package com.jr.poemas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MASuperacion extends AppCompatActivity implements View.OnClickListener {
private Button buttonS1, buttonS2, buttonS3, btnCloseS;
private TextView txtPoema;
private ImageView imgPoema;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_masuperacion);

        buttonS1 = findViewById(R.id.btnPoemaS1);
        buttonS1.setOnClickListener(this);

        buttonS2 = findViewById(R.id.btnPoemaS2);
        buttonS2.setOnClickListener(this);

        buttonS3 = findViewById(R.id.btnPoemaS3);
        buttonS3.setOnClickListener(this);

        btnCloseS = findViewById(R.id.btnCloseS);
        btnCloseS.setOnClickListener(this);

        imgPoema = findViewById(R.id.imgSupera);
        txtPoema = findViewById(R.id.txtSuperacion);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.btnPoemaS1:{
                txtPoema.setText(R.string.PS1);
                imgPoema.setImageResource(R.drawable.ic_gabriela_mistral);

                break;
            }
            case R.id.btnPoemaS2:{
                txtPoema.setText(R.string.PS2);
                imgPoema.setImageResource(R.drawable.ic_rosalia_de_castro);

                break;
            }
            case R.id.btnPoemaS3:{
                txtPoema.setText(R.string.PS3);
                imgPoema.setImageResource(R.drawable.ic_emily_dickinson);
                break;
            }

            case R.id.btnCloseS:{
                this.finish();
                break;
            }
            default: break;
        }

    }
}