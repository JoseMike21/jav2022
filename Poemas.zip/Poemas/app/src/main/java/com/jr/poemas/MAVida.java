package com.jr.poemas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MAVida extends AppCompatActivity implements View.OnClickListener {
    private Button buttonPV1, buttonPV2, buttonPV3, btnCloseV;
    private TextView txtPoema;
    private ImageView imgPoema;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mavida);

        buttonPV1 = findViewById(R.id.btnPoemaV1);
        buttonPV1.setOnClickListener(this);

        buttonPV2 = findViewById(R.id.btnPoemaV2);
        buttonPV2.setOnClickListener(this);

        buttonPV3 = findViewById(R.id.btnPoemaV3);
        buttonPV3.setOnClickListener(this);

        btnCloseV = findViewById(R.id.btnCloseV);
        btnCloseV.setOnClickListener(this);

        imgPoema = findViewById(R.id.imgVida);
        txtPoema = findViewById(R.id.txtVida);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnPoemaV1:{
                txtPoema.setText(R.string.PV1);
                imgPoema.setImageResource(R.drawable.ic_octacio_paz);
                break;
            }
            case R.id.btnPoemaV2:{
                txtPoema.setText(R.string.PV2);
                imgPoema.setImageResource(R.drawable.ic_cortazar);
                break;
            }
            case R.id.btnPoemaV3:{
                txtPoema.setText(R.string.PV3);
                imgPoema.setImageResource(R.drawable.ic_gloria_fuentes);
                break;
            }

            case R.id.btnCloseV:{
                this.finish();
                break;
            }

            default: break;
        }
    }
}