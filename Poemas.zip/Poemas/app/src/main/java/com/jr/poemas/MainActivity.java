package com.jr.poemas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
private Button buttonR, buttonV, buttonS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonR = findViewById(R.id.btnRomantico);
        buttonR.setOnClickListener(this);

        buttonV = findViewById(R.id.btnVida);
        buttonV.setOnClickListener(this);

        buttonS = findViewById(R.id.btnSuperacion);
        buttonS.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {


        switch (view.getId()){
            case R.id.btnRomantico:{
                Intent intent = new Intent(this, MARomanticos.class);
                startActivity(intent);
               // finish();

                break;
            }
            case R.id.btnVida:{
                Intent intent = new Intent(this, MAVida.class);
                startActivity(intent);
               // finish();

                break;
            }
            case R.id.btnSuperacion:{
                Intent intent = new Intent(this, MASuperacion.class);
                startActivity(intent);
               // finish();
                break;
            }
            default: break;
        }
    }
}