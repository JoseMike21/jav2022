package com.jr.anhobisiesto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
private TextView txtAnho;
private Button btnCalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtAnho = findViewById(R.id.etxAnho);

        btnCalcular = findViewById(R.id.btnCalcular);
        btnCalcular.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnCalcular){
            enviarInfo();

        }

    }

    private void enviarInfo(){
        String valor = txtAnho.getText().toString();
        if (!valor.isEmpty()){
            Intent intent = new Intent(this, CalculoAnho.class);
            intent.putExtra("valor", valor);
            startActivity(intent);

        }
        else {
            System.err.println("Dato no valido, ingrese de nuevo");
        }

    }
}