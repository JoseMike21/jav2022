package com.jr.anhobisiesto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class CalculoAnho extends AppCompatActivity {
private TextView ano, mes, semana, dia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_anho);

        ano = findViewById(R.id.txtAnio);
        mes = findViewById(R.id.txtMes);
        semana = findViewById(R.id.txtSemana);
        dia = findViewById(R.id.txtDias);

        calculo();
    }

    private void calculo() {
        Bundle bundle = getIntent().getExtras();
        Integer cantAnos, cantMeses, cantSemanas, cantDias;

       if (!bundle.isEmpty()){
           Float anoNum =  Float.parseFloat(bundle.getString("valor"));

           //calculo bisiesto
           if(anoNum%400f ==0f){
               ano.setText("Si es bisiesto");
               cantDias = 366;

               }else
               {
                   if((anoNum%100f != 0f) && (anoNum%4 == 0f)){
                      ano.setText("Si es bisiesto");
                       cantDias = 366;

               }else{
                       ano.setText("No es Bisiesto");
                       cantDias = 365;

                   }

           }

           cantSemanas = cantDias/7;
           cantMeses = cantDias/30;

            mes.setText("El año tiene: " + String.valueOf(cantMeses) + " meses");
            semana.setText("El año tiene: " + String.valueOf(cantSemanas) + " semanas");
            dia.setText("El año tiene: " + String.valueOf(cantDias) + " dias");








       }
    }
}